package com.tcs.ultimatix.ssg.ComapareChanges;

import com.tcs.ultimatix.ssg.dao.SaveChangedFieldsDao;
import com.tcs.ultimatix.ssg.dao.SaveChangedFieldsDaoImpl;
import com.tcs.ultimatix.ssg.exception.ComparisonException;
import com.tcs.ultimatix.ssg.service.SaveChangedFields;
import com.tcs.ultimatix.ssg.service.SaveChangedFieldsImpl;

public class CompTest {

	public static void main(String[] args) throws ComparisonException {
		SaveChangedFieldsDaoImpl dao=new SaveChangedFieldsDaoImpl();
		
		/*try {
		String data=	dao.getLatestCompanyData();
		String data2=dao.getLastUpdatedCompanyData();
		System.out.println(data);
		System.out.println("the second query result"+data2);
		} catch (ComparisonException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		SaveChangedFields ss=new SaveChangedFieldsImpl(); 
		
		ss.check();
		
		//dao.getLatestCompanyData();
	}
		
	}
			
			
		


