package com.tcs.ultimatix.ssg.exception;

public class ComparisonException extends Exception {
	 private static final long serialVersionUID = 1L;
	   // private static final Logger LOGGER =  new Logger(AuthenticationException.class);

	    /**
	     * 
	     * @param message
	     */
	    public ComparisonException(String message) {
	    	
	    	super(message);
	        //LOGGER.info("-----Custom AuthenticationService Exception-----" + message);
	    }

}
