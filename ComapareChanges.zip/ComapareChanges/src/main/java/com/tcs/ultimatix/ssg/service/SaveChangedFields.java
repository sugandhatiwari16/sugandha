package com.tcs.ultimatix.ssg.service;

import com.tcs.ultimatix.ssg.exception.ComparisonException;

public interface SaveChangedFields {
	public void check() throws ComparisonException;

}
