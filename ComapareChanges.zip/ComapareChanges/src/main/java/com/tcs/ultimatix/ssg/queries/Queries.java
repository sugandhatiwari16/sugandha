package com.tcs.ultimatix.ssg.queries;

public class Queries {
	/**
	 * @author 886117
	 */
	
	public static final String GETLatestUpdatedData = "select company_data,created_on from ssgtw.ssg_company_data WHERE created_on = (SELECT MAX(created_on) FROM ssgtw.ssg_company_data where tcs_id=?) and tcs_id = ?";
	
//	public static final String GETLatestUpdatedData = "select company_data from ssgtw.ssg_company_data where tcs_id=2848";

	
	public static final String GETLastUpdatedData= "SELECT  company_data ,tcs_id,created_on "+
			"FROM ssgtw.ssg_company_data "+
			"WHERE created_on = (SELECT MAX(created_on) "+ 
			               "FROM ssgtw.ssg_company_data "+
			               "WHERE created_on < ( SELECT MAX(created_on) "+ 
			                              "FROM ssgtw.ssg_company_data " +
			                           "where tcs_id=? ) and tcs_id=?) ";
	
	/**
	 * 
	 */
	public static final String getListOfTcsId =  "select tcs_id from ssgtw.ssg_company_master ";
	
			              
	
	public Queries(){
		
	}

}
