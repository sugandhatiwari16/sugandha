package com.tcs.ultimatix.ssg.dto;

public class UpdatedRecordsDto {
	private String dnbRefId;
	private String filler1;
	private String dunsNumber;
	private String businessName;
	private String secondaryName;
	private String registeredAddressIndicator;
	private String streetAddress;
	private String streetAddress2;
	private String cityName;
	private String stateName;
	private String countryName;
	private String cityCode;
	private String countyCode;
	private String stateCode;
	private String stateAbbreviation;
	private String countryCode;
	private String postalCodeForStreetAddress;
	private String continentCode;
	private String mailingAddress;
	private String mailingCityName;
	private String mailingCountyName;
	private String mailingStateName;
	private String mailingCountryName;
	private String mailingCityCode;
	private String mailingCountyCode;
	private String mailingStateCode;
	private String mailingStateAbbreviation;
	private String mailingCountryCode;
	private String postalCodeForMailingAddress;
	private String mailingContinentCode;
	private String nationalIdentificationNumber;
	private String nationalIdentificationSystemCode;
	private String countryTelephoneAccessCode;
	private String telephoneNumber;
	private String cableTelex;
	private String faxNumber;
	private String chiefExecutiveOfficerName;
	private String chiefExecutiveOfficerTitle;
	private String lineOfBusiness;
	private String us1987Sic1;
	private String us1987Sic2;
	private String us1987Sic3;
	private String us1987Sic4;
	private String us1987Sic5;
	private String us1987Sic6;
	private String us1987Sic1Name;
	private String us1987Sic2Name;
	private String us1987Sic3Name;
	private String us1987Sic4Name;
	private String us1987Sic5Name;
	private String us1987Sic6Name;
	private String primaryLocalActivityCode;
	private String activityIndicator;
	private String yearStarted;
	private String annualSalesLocal;
	private String annualSalesIndicator;
	private String annualSalesInUsDollars;
	private String currencyCode;
	private String employeeHere;
	private String employeeHereIndicator;
	private String employeeTotal;
	private String employeeTotalIndicator;
	private String includePrinciplesIndicator;
	private String agentIndicator;
	private String legalStatus;
	private String controlIndicator;
	private String statusCode;
	private String subsidiaryCode;
	private String filler2;
	private String previousDunsNumber;
	private String reportDate;
	private String filler3;
	private String headquarterDunsNumber;
	private String headquarterBusinessName;
	private String headquarterStreetAddress;
	private String headquarterCity;
	private String headquarterState;
	private String headquarterCountryName;
	private String headquarterCityCode;
	private String headquarterCountyCode;
	private String headquarterStateAbbreviation;
	private String headquarterCountryCode;
	private String headquarterPostalCode;
	private String headquarterContinentCode;
	private String filler4;
	private String domesticUltimateDunsNumber;
	private String domesticUltimateBusinessName;
	private String domesticUltimateStreetAddress;
	private String domesticUltimateCityName;
	private String domesticUltimateStateName;
	private String domesticUltimateCityCode;
	private String domesticUltimateCountryCode;
	private String domesticUltimateStateAbbreviation;
	private String domesticUltimatePostalCode;
	private String globalUltimateIndicator;
	private String filler5;
	private String globalUltimateDunsNumber;
	private String globalUltimateName;
	private String globalUltimateStreetAddress;
	private String globalUltimateCityName;
	private String globalUltimateState;
	private String globalUltimateCountryName;
	private String globalUltimateCityCode;
	private String globalUltimateCountyCode;
	private String globalultimateStateAbbreviation;
	private String globalUltimateCountryCode;
	private String globalUltimatePostalCode;
	private String globalUltimateContinentCode;
	private String globalUltimateUS1987PrimarySICCode;
	private String globalUltimateEmployeesTotal;
	private String globalUltimateAnnualSales;
	private String numberOfFamilyMembers;
	private String diasCode;
	private String hierarchyCode;
	private String familyUpdateDate;
	private String outOfBusinessIndicator;
	private String marketableIndicator;
	private String locationOOB;
	private String entityOOB;
	public String getDnbRefId() {
		return dnbRefId;
	}
	public void setDnbRefId(String dnbRefId) {
		this.dnbRefId = dnbRefId;
	}
	public String getFiller1() {
		return filler1;
	}
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	public String getDunsNumber() {
		return dunsNumber;
	}
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getSecondaryName() {
		return secondaryName;
	}
	public void setSecondaryName(String secondaryName) {
		this.secondaryName = secondaryName;
	}
	public String getRegisteredAddressIndicator() {
		return registeredAddressIndicator;
	}
	public void setRegisteredAddressIndicator(String registeredAddressIndicator) {
		this.registeredAddressIndicator = registeredAddressIndicator;
	}
	public String getStreetAddress() {
		return streetAddress;
	}
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	public String getStreetAddress2() {
		return streetAddress2;
	}
	public void setStreetAddress2(String streetAddress2) {
		this.streetAddress2 = streetAddress2;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCountyCode() {
		return countyCode;
	}
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getStateAbbreviation() {
		return stateAbbreviation;
	}
	public void setStateAbbreviation(String stateAbbreviation) {
		this.stateAbbreviation = stateAbbreviation;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getPostalCodeForStreetAddress() {
		return postalCodeForStreetAddress;
	}
	public void setPostalCodeForStreetAddress(String postalCodeForStreetAddress) {
		this.postalCodeForStreetAddress = postalCodeForStreetAddress;
	}
	public String getContinentCode() {
		return continentCode;
	}
	public void setContinentCode(String continentCode) {
		this.continentCode = continentCode;
	}
	public String getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	public String getMailingCityName() {
		return mailingCityName;
	}
	public void setMailingCityName(String mailingCityName) {
		this.mailingCityName = mailingCityName;
	}
	public String getMailingCountyName() {
		return mailingCountyName;
	}
	public void setMailingCountyName(String mailingCountyName) {
		this.mailingCountyName = mailingCountyName;
	}
	public String getMailingStateName() {
		return mailingStateName;
	}
	public void setMailingStateName(String mailingStateName) {
		this.mailingStateName = mailingStateName;
	}
	public String getMailingCountryName() {
		return mailingCountryName;
	}
	public void setMailingCountryName(String mailingCountryName) {
		this.mailingCountryName = mailingCountryName;
	}
	public String getMailingCityCode() {
		return mailingCityCode;
	}
	public void setMailingCityCode(String mailingCityCode) {
		this.mailingCityCode = mailingCityCode;
	}
	public String getMailingCountyCode() {
		return mailingCountyCode;
	}
	public void setMailingCountyCode(String mailingCountyCode) {
		this.mailingCountyCode = mailingCountyCode;
	}
	public String getMailingStateCode() {
		return mailingStateCode;
	}
	public void setMailingStateCode(String mailingStateCode) {
		this.mailingStateCode = mailingStateCode;
	}
	public String getMailingStateAbbreviation() {
		return mailingStateAbbreviation;
	}
	public void setMailingStateAbbreviation(String mailingStateAbbreviation) {
		this.mailingStateAbbreviation = mailingStateAbbreviation;
	}
	public String getMailingCountryCode() {
		return mailingCountryCode;
	}
	public void setMailingCountryCode(String mailingCountryCode) {
		this.mailingCountryCode = mailingCountryCode;
	}
	public String getPostalCodeForMailingAddress() {
		return postalCodeForMailingAddress;
	}
	public void setPostalCodeForMailingAddress(String postalCodeForMailingAddress) {
		this.postalCodeForMailingAddress = postalCodeForMailingAddress;
	}
	public String getMailingContinentCode() {
		return mailingContinentCode;
	}
	public void setMailingContinentCode(String mailingContinentCode) {
		this.mailingContinentCode = mailingContinentCode;
	}
	public String getNationalIdentificationNumber() {
		return nationalIdentificationNumber;
	}
	public void setNationalIdentificationNumber(String nationalIdentificationNumber) {
		this.nationalIdentificationNumber = nationalIdentificationNumber;
	}
	public String getNationalIdentificationSystemCode() {
		return nationalIdentificationSystemCode;
	}
	public void setNationalIdentificationSystemCode(
			String nationalIdentificationSystemCode) {
		this.nationalIdentificationSystemCode = nationalIdentificationSystemCode;
	}
	public String getCountryTelephoneAccessCode() {
		return countryTelephoneAccessCode;
	}
	public void setCountryTelephoneAccessCode(String countryTelephoneAccessCode) {
		this.countryTelephoneAccessCode = countryTelephoneAccessCode;
	}
	public String getTelephoneNumber() {
		return telephoneNumber;
	}
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	public String getCableTelex() {
		return cableTelex;
	}
	public void setCableTelex(String cableTelex) {
		this.cableTelex = cableTelex;
	}
	public String getFaxNumber() {
		return faxNumber;
	}
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	public String getChiefExecutiveOfficerName() {
		return chiefExecutiveOfficerName;
	}
	public void setChiefExecutiveOfficerName(String chiefExecutiveOfficerName) {
		this.chiefExecutiveOfficerName = chiefExecutiveOfficerName;
	}
	public String getChiefExecutiveOfficerTitle() {
		return chiefExecutiveOfficerTitle;
	}
	public void setChiefExecutiveOfficerTitle(String chiefExecutiveOfficerTitle) {
		this.chiefExecutiveOfficerTitle = chiefExecutiveOfficerTitle;
	}
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	public String getUs1987Sic1() {
		return us1987Sic1;
	}
	public void setUs1987Sic1(String us1987Sic1) {
		this.us1987Sic1 = us1987Sic1;
	}
	public String getUs1987Sic2() {
		return us1987Sic2;
	}
	public void setUs1987Sic2(String us1987Sic2) {
		this.us1987Sic2 = us1987Sic2;
	}
	public String getUs1987Sic3() {
		return us1987Sic3;
	}
	public void setUs1987Sic3(String us1987Sic3) {
		this.us1987Sic3 = us1987Sic3;
	}
	public String getUs1987Sic4() {
		return us1987Sic4;
	}
	public void setUs1987Sic4(String us1987Sic4) {
		this.us1987Sic4 = us1987Sic4;
	}
	public String getUs1987Sic5() {
		return us1987Sic5;
	}
	public void setUs1987Sic5(String us1987Sic5) {
		this.us1987Sic5 = us1987Sic5;
	}
	public String getUs1987Sic6() {
		return us1987Sic6;
	}
	public void setUs1987Sic6(String us1987Sic6) {
		this.us1987Sic6 = us1987Sic6;
	}
	public String getUs1987Sic1Name() {
		return us1987Sic1Name;
	}
	public void setUs1987Sic1Name(String us1987Sic1Name) {
		this.us1987Sic1Name = us1987Sic1Name;
	}
	public String getUs1987Sic2Name() {
		return us1987Sic2Name;
	}
	public void setUs1987Sic2Name(String us1987Sic2Name) {
		this.us1987Sic2Name = us1987Sic2Name;
	}
	public String getUs1987Sic3Name() {
		return us1987Sic3Name;
	}
	public void setUs1987Sic3Name(String us1987Sic3Name) {
		this.us1987Sic3Name = us1987Sic3Name;
	}
	public String getUs1987Sic4Name() {
		return us1987Sic4Name;
	}
	public void setUs1987Sic4Name(String us1987Sic4Name) {
		this.us1987Sic4Name = us1987Sic4Name;
	}
	public String getUs1987Sic5Name() {
		return us1987Sic5Name;
	}
	public void setUs1987Sic5Name(String us1987Sic5Name) {
		this.us1987Sic5Name = us1987Sic5Name;
	}
	public String getUs1987Sic6Name() {
		return us1987Sic6Name;
	}
	public void setUs1987Sic6Name(String us1987Sic6Name) {
		this.us1987Sic6Name = us1987Sic6Name;
	}
	public String getPrimaryLocalActivityCode() {
		return primaryLocalActivityCode;
	}
	public void setPrimaryLocalActivityCode(String primaryLocalActivityCode) {
		this.primaryLocalActivityCode = primaryLocalActivityCode;
	}
	public String getActivityIndicator() {
		return activityIndicator;
	}
	public void setActivityIndicator(String activityIndicator) {
		this.activityIndicator = activityIndicator;
	}
	public String getYearStarted() {
		return yearStarted;
	}
	public void setYearStarted(String yearStarted) {
		this.yearStarted = yearStarted;
	}
	public String getAnnualSalesLocal() {
		return annualSalesLocal;
	}
	public void setAnnualSalesLocal(String annualSalesLocal) {
		this.annualSalesLocal = annualSalesLocal;
	}
	public String getAnnualSalesIndicator() {
		return annualSalesIndicator;
	}
	public void setAnnualSalesIndicator(String annualSalesIndicator) {
		this.annualSalesIndicator = annualSalesIndicator;
	}
	public String getAnnualSalesInUsDollars() {
		return annualSalesInUsDollars;
	}
	public void setAnnualSalesInUsDollars(String annualSalesInUsDollars) {
		this.annualSalesInUsDollars = annualSalesInUsDollars;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getEmployeeHere() {
		return employeeHere;
	}
	public void setEmployeeHere(String employeeHere) {
		this.employeeHere = employeeHere;
	}
	public String getEmployeeHereIndicator() {
		return employeeHereIndicator;
	}
	public void setEmployeeHereIndicator(String employeeHereIndicator) {
		this.employeeHereIndicator = employeeHereIndicator;
	}
	public String getEmployeeTotal() {
		return employeeTotal;
	}
	public void setEmployeeTotal(String employeeTotal) {
		this.employeeTotal = employeeTotal;
	}
	public String getEmployeeTotalIndicator() {
		return employeeTotalIndicator;
	}
	public void setEmployeeTotalIndicator(String employeeTotalIndicator) {
		this.employeeTotalIndicator = employeeTotalIndicator;
	}
	public String getIncludePrinciplesIndicator() {
		return includePrinciplesIndicator;
	}
	public void setIncludePrinciplesIndicator(String includePrinciplesIndicator) {
		this.includePrinciplesIndicator = includePrinciplesIndicator;
	}
	public String getAgentIndicator() {
		return agentIndicator;
	}
	public void setAgentIndicator(String agentIndicator) {
		this.agentIndicator = agentIndicator;
	}
	public String getLegalStatus() {
		return legalStatus;
	}
	public void setLegalStatus(String legalStatus) {
		this.legalStatus = legalStatus;
	}
	public String getControlIndicator() {
		return controlIndicator;
	}
	public void setControlIndicator(String controlIndicator) {
		this.controlIndicator = controlIndicator;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getSubsidiaryCode() {
		return subsidiaryCode;
	}
	public void setSubsidiaryCode(String subsidiaryCode) {
		this.subsidiaryCode = subsidiaryCode;
	}
	public String getFiller2() {
		return filler2;
	}
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
	public String getPreviousDunsNumber() {
		return previousDunsNumber;
	}
	public void setPreviousDunsNumber(String previousDunsNumber) {
		this.previousDunsNumber = previousDunsNumber;
	}
	public String getReportDate() {
		return reportDate;
	}
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}
	public String getFiller3() {
		return filler3;
	}
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}
	public String getHeadquarterDunsNumber() {
		return headquarterDunsNumber;
	}
	public void setHeadquarterDunsNumber(String headquarterDunsNumber) {
		this.headquarterDunsNumber = headquarterDunsNumber;
	}
	public String getHeadquarterBusinessName() {
		return headquarterBusinessName;
	}
	public void setHeadquarterBusinessName(String headquarterBusinessName) {
		this.headquarterBusinessName = headquarterBusinessName;
	}
	public String getHeadquarterStreetAddress() {
		return headquarterStreetAddress;
	}
	public void setHeadquarterStreetAddress(String headquarterStreetAddress) {
		this.headquarterStreetAddress = headquarterStreetAddress;
	}
	public String getHeadquarterCity() {
		return headquarterCity;
	}
	public void setHeadquarterCity(String headquarterCity) {
		this.headquarterCity = headquarterCity;
	}
	public String getHeadquarterState() {
		return headquarterState;
	}
	public void setHeadquarterState(String headquarterState) {
		this.headquarterState = headquarterState;
	}
	public String getHeadquarterCountryName() {
		return headquarterCountryName;
	}
	public void setHeadquarterCountryName(String headquarterCountryName) {
		this.headquarterCountryName = headquarterCountryName;
	}
	public String getHeadquarterCityCode() {
		return headquarterCityCode;
	}
	public void setHeadquarterCityCode(String headquarterCityCode) {
		this.headquarterCityCode = headquarterCityCode;
	}
	public String getHeadquarterCountyCode() {
		return headquarterCountyCode;
	}
	public void setHeadquarterCountyCode(String headquarterCountyCode) {
		this.headquarterCountyCode = headquarterCountyCode;
	}
	public String getHeadquarterStateAbbreviation() {
		return headquarterStateAbbreviation;
	}
	public void setHeadquarterStateAbbreviation(String headquarterStateAbbreviation) {
		this.headquarterStateAbbreviation = headquarterStateAbbreviation;
	}
	public String getHeadquarterCountryCode() {
		return headquarterCountryCode;
	}
	public void setHeadquarterCountryCode(String headquarterCountryCode) {
		this.headquarterCountryCode = headquarterCountryCode;
	}
	public String getHeadquarterPostalCode() {
		return headquarterPostalCode;
	}
	public void setHeadquarterPostalCode(String headquarterPostalCode) {
		this.headquarterPostalCode = headquarterPostalCode;
	}
	public String getHeadquarterContinentCode() {
		return headquarterContinentCode;
	}
	public void setHeadquarterContinentCode(String headquarterContinentCode) {
		this.headquarterContinentCode = headquarterContinentCode;
	}
	public String getFiller4() {
		return filler4;
	}
	public void setFiller4(String filler4) {
		this.filler4 = filler4;
	}
	public String getDomesticUltimateDunsNumber() {
		return domesticUltimateDunsNumber;
	}
	public void setDomesticUltimateDunsNumber(String domesticUltimateDunsNumber) {
		this.domesticUltimateDunsNumber = domesticUltimateDunsNumber;
	}
	public String getDomesticUltimateBusinessName() {
		return domesticUltimateBusinessName;
	}
	public void setDomesticUltimateBusinessName(String domesticUltimateBusinessName) {
		this.domesticUltimateBusinessName = domesticUltimateBusinessName;
	}
	public String getDomesticUltimateStreetAddress() {
		return domesticUltimateStreetAddress;
	}
	public void setDomesticUltimateStreetAddress(
			String domesticUltimateStreetAddress) {
		this.domesticUltimateStreetAddress = domesticUltimateStreetAddress;
	}
	public String getDomesticUltimateCityName() {
		return domesticUltimateCityName;
	}
	public void setDomesticUltimateCityName(String domesticUltimateCityName) {
		this.domesticUltimateCityName = domesticUltimateCityName;
	}
	public String getDomesticUltimateStateName() {
		return domesticUltimateStateName;
	}
	public void setDomesticUltimateStateName(String domesticUltimateStateName) {
		this.domesticUltimateStateName = domesticUltimateStateName;
	}
	public String getDomesticUltimateCityCode() {
		return domesticUltimateCityCode;
	}
	public void setDomesticUltimateCityCode(String domesticUltimateCityCode) {
		this.domesticUltimateCityCode = domesticUltimateCityCode;
	}
	public String getDomesticUltimateCountryCode() {
		return domesticUltimateCountryCode;
	}
	public void setDomesticUltimateCountryCode(String domesticUltimateCountryCode) {
		this.domesticUltimateCountryCode = domesticUltimateCountryCode;
	}
	public String getDomesticUltimateStateAbbreviation() {
		return domesticUltimateStateAbbreviation;
	}
	public void setDomesticUltimateStateAbbreviation(
			String domesticUltimateStateAbbreviation) {
		this.domesticUltimateStateAbbreviation = domesticUltimateStateAbbreviation;
	}
	public String getDomesticUltimatePostalCode() {
		return domesticUltimatePostalCode;
	}
	public void setDomesticUltimatePostalCode(String domesticUltimatePostalCode) {
		this.domesticUltimatePostalCode = domesticUltimatePostalCode;
	}
	public String getGlobalUltimateIndicator() {
		return globalUltimateIndicator;
	}
	public void setGlobalUltimateIndicator(String globalUltimateIndicator) {
		this.globalUltimateIndicator = globalUltimateIndicator;
	}
	public String getFiller5() {
		return filler5;
	}
	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}
	public String getGlobalUltimateDunsNumber() {
		return globalUltimateDunsNumber;
	}
	public void setGlobalUltimateDunsNumber(String globalUltimateDunsNumber) {
		this.globalUltimateDunsNumber = globalUltimateDunsNumber;
	}
	public String getGlobalUltimateName() {
		return globalUltimateName;
	}
	public void setGlobalUltimateName(String globalUltimateName) {
		this.globalUltimateName = globalUltimateName;
	}
	public String getGlobalUltimateStreetAddress() {
		return globalUltimateStreetAddress;
	}
	public void setGlobalUltimateStreetAddress(String globalUltimateStreetAddress) {
		this.globalUltimateStreetAddress = globalUltimateStreetAddress;
	}
	public String getGlobalUltimateCityName() {
		return globalUltimateCityName;
	}
	public void setGlobalUltimateCityName(String globalUltimateCityName) {
		this.globalUltimateCityName = globalUltimateCityName;
	}
	public String getGlobalUltimateState() {
		return globalUltimateState;
	}
	public void setGlobalUltimateState(String globalUltimateState) {
		this.globalUltimateState = globalUltimateState;
	}
	public String getGlobalUltimateCountryName() {
		return globalUltimateCountryName;
	}
	public void setGlobalUltimateCountryName(String globalUltimateCountryName) {
		this.globalUltimateCountryName = globalUltimateCountryName;
	}
	public String getGlobalUltimateCityCode() {
		return globalUltimateCityCode;
	}
	public void setGlobalUltimateCityCode(String globalUltimateCityCode) {
		this.globalUltimateCityCode = globalUltimateCityCode;
	}
	public String getGlobalUltimateCountyCode() {
		return globalUltimateCountyCode;
	}
	public void setGlobalUltimateCountyCode(String globalUltimateCountyCode) {
		this.globalUltimateCountyCode = globalUltimateCountyCode;
	}
	public String getGlobalultimateStateAbbreviation() {
		return globalultimateStateAbbreviation;
	}
	public void setGlobalultimateStateAbbreviation(
			String globalultimateStateAbbreviation) {
		this.globalultimateStateAbbreviation = globalultimateStateAbbreviation;
	}
	public String getGlobalUltimateCountryCode() {
		return globalUltimateCountryCode;
	}
	public void setGlobalUltimateCountryCode(String globalUltimateCountryCode) {
		this.globalUltimateCountryCode = globalUltimateCountryCode;
	}
	public String getGlobalUltimatePostalCode() {
		return globalUltimatePostalCode;
	}
	public void setGlobalUltimatePostalCode(String globalUltimatePostalCode) {
		this.globalUltimatePostalCode = globalUltimatePostalCode;
	}
	public String getGlobalUltimateContinentCode() {
		return globalUltimateContinentCode;
	}
	public void setGlobalUltimateContinentCode(String globalUltimateContinentCode) {
		this.globalUltimateContinentCode = globalUltimateContinentCode;
	}
	public String getGlobalUltimateUS1987PrimarySICCode() {
		return globalUltimateUS1987PrimarySICCode;
	}
	public void setGlobalUltimateUS1987PrimarySICCode(
			String globalUltimateUS1987PrimarySICCode) {
		this.globalUltimateUS1987PrimarySICCode = globalUltimateUS1987PrimarySICCode;
	}
	public String getGlobalUltimateEmployeesTotal() {
		return globalUltimateEmployeesTotal;
	}
	public void setGlobalUltimateEmployeesTotal(String globalUltimateEmployeesTotal) {
		this.globalUltimateEmployeesTotal = globalUltimateEmployeesTotal;
	}
	public String getGlobalUltimateAnnualSales() {
		return globalUltimateAnnualSales;
	}
	public void setGlobalUltimateAnnualSales(String globalUltimateAnnualSales) {
		this.globalUltimateAnnualSales = globalUltimateAnnualSales;
	}
	public String getNumberOfFamilyMembers() {
		return numberOfFamilyMembers;
	}
	public void setNumberOfFamilyMembers(String numberOfFamilyMembers) {
		this.numberOfFamilyMembers = numberOfFamilyMembers;
	}
	public String getDiasCode() {
		return diasCode;
	}
	public void setDiasCode(String diasCode) {
		this.diasCode = diasCode;
	}
	public String getHierarchyCode() {
		return hierarchyCode;
	}
	public void setHierarchyCode(String hierarchyCode) {
		this.hierarchyCode = hierarchyCode;
	}
	public String getFamilyUpdateDate() {
		return familyUpdateDate;
	}
	public void setFamilyUpdateDate(String familyUpdateDate) {
		this.familyUpdateDate = familyUpdateDate;
	}
	public String getOutOfBusinessIndicator() {
		return outOfBusinessIndicator;
	}
	public void setOutOfBusinessIndicator(String outOfBusinessIndicator) {
		this.outOfBusinessIndicator = outOfBusinessIndicator;
	}
	public String getMarketableIndicator() {
		return marketableIndicator;
	}
	public void setMarketableIndicator(String marketableIndicator) {
		this.marketableIndicator = marketableIndicator;
	}
	public String getLocationOOB() {
		return locationOOB;
	}
	public void setLocationOOB(String locationOOB) {
		this.locationOOB = locationOOB;
	}
	public String getEntityOOB() {
		return entityOOB;
	}
	public void setEntityOOB(String entityOOB) {
		this.entityOOB = entityOOB;
	}


}
