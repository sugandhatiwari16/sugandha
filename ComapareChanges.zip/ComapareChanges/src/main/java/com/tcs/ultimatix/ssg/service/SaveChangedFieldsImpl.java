package com.tcs.ultimatix.ssg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tcs.ultimatix.ssg.exception.ComparisonException;
import com.tcs.ultimatix.ssg.model.SaveChangedFieldsModel;

public class SaveChangedFieldsImpl implements SaveChangedFields {
@Autowired




	ApplicationContext context = new ClassPathXmlApplicationContext("Authentication.xml");
	SaveChangedFieldsModel model = (SaveChangedFieldsModel)context.getBean("model");

	
	
	public void check() throws ComparisonException{
		model.compareAllFields();
	}
}
