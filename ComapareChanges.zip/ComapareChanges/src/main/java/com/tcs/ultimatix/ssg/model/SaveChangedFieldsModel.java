package com.tcs.ultimatix.ssg.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.print.attribute.HashAttributeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.ultimatix.ssg.dao.SaveChangedFieldsDao;
import com.tcs.ultimatix.ssg.dto.ComparisonDto;
import com.tcs.ultimatix.ssg.dto.LastUpdatedDataDto;
import com.tcs.ultimatix.ssg.dto.UpdatedRecordsDto;
import com.tcs.ultimatix.ssg.exception.ComparisonException;

public class SaveChangedFieldsModel {


List<ComparisonDto> listComparisonDto =new ArrayList<ComparisonDto>();
	Map<Integer,List<ComparisonDto>> mapCompDto = new HashMap<Integer, List<ComparisonDto>>();
	
	@Autowired
	SaveChangedFieldsDao dao;

	private void compareJsonStrings(Map<Integer,String> latestCopmanyDataJson,Map<Integer,String> lastUpdatedCompData) throws ComparisonException {
		System.out.println("------------------into compareJsonStrings ");
		boolean areTheyEqual = false;

		for (Map.Entry<Integer, String> entry1 : latestCopmanyDataJson.entrySet()) {
			//for(Map.Entry<Integer, String> entry2 : lastUpdatedCompData.entrySet()){
			//	System.out.println(entry1.getKey()+" "+entry2.getKey());
			if(lastUpdatedCompData.containsKey(entry1.getKey())){
				System.out.println("------------------inside if tcs id "+entry1.getKey());

				try {
					/*String newCopmanyDataJson = dao.getLatestCompanyData();
			String lastUpdatedCompData =dao.getLastUpdatedCompanyData();*/

					ObjectMapper mapper = new ObjectMapper();


					JsonNode tree1 = mapper.readTree(entry1.getValue());
					JsonNode tree2 = mapper.readTree(lastUpdatedCompData.get(entry1.getKey()));
					areTheyEqual = tree1.equals(tree2);
					System.out.println(areTheyEqual);
					abcd(entry1.getValue(),lastUpdatedCompData.get(entry1.getKey()),areTheyEqual,entry1.getKey());

				} catch (JsonProcessingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}


	private void abcd(String latestUpdatedData,
			String lastUpdatedData, boolean areTheyEqual, Integer tcsId) {
		try{
			if(areTheyEqual==false){
				System.out.println("inside if ");
				ObjectMapper mapper = new ObjectMapper();

				UpdatedRecordsDto mappedDtoUpdtd = mapper.readValue(latestUpdatedData, UpdatedRecordsDto.class);

				LastUpdatedDataDto mappedDtoOld = mapper.readValue(lastUpdatedData, LastUpdatedDataDto.class); 
				//System.out.println("value from json updated "+mappedDtoUpdtd.getDnbRefId());
				//System.out.println("user value from json old "+mappedDtoOld.getDnbRefId());
				//System.out.println();

				System.out.println("initial listCompDto list  size : "+mapCompDto.size());

				

				//------------------------------------------------------------------------------------------------//



				comapreFunction (mappedDtoOld.getDnbRefId(),mappedDtoUpdtd.getDnbRefId(),"dnbRefId",tcsId);
				comapreFunction (mappedDtoOld.getFiller1(),mappedDtoUpdtd.getFiller1(),"Filler1",tcsId);
				comapreFunction (mappedDtoOld.getDunsNumber(),mappedDtoUpdtd.getDunsNumber(),"getDunsNumber", tcsId);
				comapreFunction (mappedDtoOld.getBusinessName(),mappedDtoUpdtd.getBusinessName(),"getBusinessName",tcsId);
				comapreFunction (mappedDtoOld.getSecondaryName(),mappedDtoUpdtd.getSecondaryName(),"getSecondaryName",tcsId);
				comapreFunction (mappedDtoOld.getRegisteredAddressIndicator(),mappedDtoUpdtd.getRegisteredAddressIndicator(),"getRegisteredAddressIndicator()",tcsId);
				comapreFunction (mappedDtoOld.getStreetAddress(),mappedDtoUpdtd.getStreetAddress(),"getStreetAddress",tcsId);
				comapreFunction (mappedDtoOld.getStreetAddress2(),mappedDtoUpdtd.getStreetAddress2(),"getStreetAddress2",tcsId);
				comapreFunction (mappedDtoOld.getCityName(),mappedDtoUpdtd.getCityName(),"getCityName",tcsId);
				comapreFunction (mappedDtoOld.getStateName(),mappedDtoUpdtd.getStateName(),"getStateName",tcsId);
				comapreFunction (mappedDtoOld.getCountryName(),mappedDtoUpdtd.getCountryName(),"getCountryName()",tcsId);
				comapreFunction (mappedDtoOld.getCityCode(),mappedDtoUpdtd.getCityCode(),"CityCode",tcsId);
				comapreFunction (mappedDtoOld.getCountyCode(),mappedDtoUpdtd.getCountyCode(),"CountyCode",tcsId);
				comapreFunction (mappedDtoOld.getStateCode(),mappedDtoUpdtd.getStateCode(),"StateCode",tcsId);
				comapreFunction (mappedDtoOld.getStateAbbreviation(),mappedDtoUpdtd.getStateAbbreviation(),"StateAbbreviation", tcsId);
				comapreFunction (mappedDtoOld.getCountryCode(),mappedDtoUpdtd.getCountryCode(),"CountryCode", tcsId);
				comapreFunction (mappedDtoOld.getPostalCodeForStreetAddress(),mappedDtoUpdtd.getPostalCodeForStreetAddress(),"PostalCodeForStreetAddress", tcsId);
				comapreFunction (mappedDtoOld.getContinentCode(),mappedDtoUpdtd.getContinentCode(),"ContinentCode()", tcsId);
				comapreFunction (mappedDtoOld.getMailingAddress(),mappedDtoUpdtd.getMailingAddress(),"MailingAddress", tcsId);
				comapreFunction (mappedDtoOld.getMailingCityName(),mappedDtoUpdtd.getMailingCityName(),"MailingCityName", tcsId);
				comapreFunction (mappedDtoOld.getMailingCountyName(),mappedDtoUpdtd.getMailingCountyName(),"MailingCountyName", tcsId);
				comapreFunction (mappedDtoOld.getMailingStateName(),mappedDtoUpdtd.getMailingStateName(),"MailingStateName", tcsId);
				comapreFunction (mappedDtoOld.getMailingCountryName(),mappedDtoUpdtd.getMailingCountryName(),"MailingCountryName",tcsId);
				comapreFunction (mappedDtoOld.getMailingCityCode(),mappedDtoUpdtd.getMailingCityCode(),"MailingCityCode",tcsId);
				comapreFunction (mappedDtoOld.getMailingCountyCode(),mappedDtoUpdtd.getMailingCountyCode(),"MailingCountyCode",tcsId);
				comapreFunction (mappedDtoOld.getMailingStateAbbreviation(),mappedDtoUpdtd.getMailingStateAbbreviation(),"MailingStateCode",tcsId);
				comapreFunction (mappedDtoOld.getMailingCountryCode(),mappedDtoUpdtd.getMailingCountryCode(),"MailingCountryCode",tcsId);
				comapreFunction (mappedDtoOld.getPostalCodeForMailingAddress(),mappedDtoUpdtd.getPostalCodeForMailingAddress(),"PostalCodeForMailingAddress",tcsId);
				comapreFunction (mappedDtoOld.getMailingContinentCode(),mappedDtoUpdtd.getMailingContinentCode(),"MailingContinentCode",tcsId);
				comapreFunction (mappedDtoOld.getNationalIdentificationNumber(),mappedDtoUpdtd.getNationalIdentificationNumber(),"NationalIdentificationNumber",tcsId);
				comapreFunction (mappedDtoOld.getNationalIdentificationSystemCode(),mappedDtoUpdtd.getNationalIdentificationSystemCode(),"NationalIdentificationSystemCode",tcsId);
				comapreFunction (mappedDtoOld.getCountryTelephoneAccessCode(),mappedDtoUpdtd.getCountryTelephoneAccessCode(),"countryTelephoneAccessCode",tcsId);
				comapreFunction (mappedDtoOld.getTelephoneNumber(),mappedDtoUpdtd.getTelephoneNumber(),"telephoneNumber",tcsId);
				comapreFunction (mappedDtoOld.getCableTelex(),mappedDtoUpdtd.getCableTelex(),"cableTelex",tcsId);
				comapreFunction (mappedDtoOld.getFaxNumber(),mappedDtoUpdtd.getFaxNumber(),"faxNumber",tcsId);
				comapreFunction (mappedDtoOld.getChiefExecutiveOfficerName(),mappedDtoUpdtd.getChiefExecutiveOfficerName(),"chiefExecutiveOfficerName",tcsId);
				comapreFunction (mappedDtoOld.getChiefExecutiveOfficerTitle(),mappedDtoUpdtd.getChiefExecutiveOfficerTitle(),"chiefExecutiveOfficerTitle",tcsId);
				comapreFunction (mappedDtoOld.getLineOfBusiness(),mappedDtoUpdtd.getLineOfBusiness(),"lineOfBusiness",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic1(),mappedDtoUpdtd.getUs1987Sic1(),"us1987Sic1",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic2(),mappedDtoUpdtd.getUs1987Sic2(),"Us1987Sic2",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic3(),mappedDtoUpdtd.getUs1987Sic3(),"Us1987Sic3",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic4(),mappedDtoUpdtd.getUs1987Sic4(),"Us1987Sic3",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic5(),mappedDtoUpdtd.getUs1987Sic5(),"us1987Sic5",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic6(),mappedDtoUpdtd.getUs1987Sic6(),"Us1987Sic6",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic1Name(),mappedDtoUpdtd.getUs1987Sic1Name(),"us1987Sic1Name",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic2Name(),mappedDtoUpdtd.getUs1987Sic2Name(),"Us1987Sic2Name",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic3Name(),mappedDtoUpdtd.getUs1987Sic3Name(),"Us1987Sic3Name",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic4Name(),mappedDtoUpdtd.getUs1987Sic4Name(),"Us1987Sic4Name",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic5Name(),mappedDtoUpdtd.getUs1987Sic5Name(),"Us1987Sic4Name",tcsId);
				comapreFunction (mappedDtoOld.getUs1987Sic6Name(),mappedDtoUpdtd.getUs1987Sic6Name(),"Us1987Sic4Name",tcsId);
				comapreFunction (mappedDtoOld.getPrimaryLocalActivityCode(),mappedDtoUpdtd.getPrimaryLocalActivityCode(),"primaryLocalActivityCode",tcsId);
				comapreFunction (mappedDtoOld.getActivityIndicator(),mappedDtoUpdtd.getActivityIndicator(),"activityIndicator",tcsId);
				comapreFunction (mappedDtoOld.getYearStarted(),mappedDtoUpdtd.getYearStarted(),"yearStarted",tcsId);
				comapreFunction (mappedDtoOld.getAnnualSalesLocal(),mappedDtoUpdtd.getAnnualSalesLocal(),"annualSalesLocal",tcsId);
				comapreFunction (mappedDtoOld.getAnnualSalesIndicator(),mappedDtoUpdtd.getAnnualSalesIndicator(),"annualSalesIndicator",tcsId);
				comapreFunction (mappedDtoOld.getAnnualSalesInUsDollars(),mappedDtoUpdtd.getAnnualSalesInUsDollars(),"annualSalesInUsDollars",tcsId);
				comapreFunction (mappedDtoOld.getCurrencyCode(),mappedDtoUpdtd.getCurrencyCode(),"currencyCode",tcsId);
				comapreFunction (mappedDtoOld.getEmployeeHere(),mappedDtoUpdtd.getEmployeeHere(),"employeeHere",tcsId);
				comapreFunction (mappedDtoOld.getEmployeeHereIndicator(),mappedDtoUpdtd.getEmployeeHereIndicator(),"employeeHereIndicator",tcsId);
				comapreFunction (mappedDtoOld.getEmployeeTotal(),mappedDtoUpdtd.getEmployeeTotal(),"employeeTotal",tcsId);
				comapreFunction (mappedDtoOld.getEmployeeTotalIndicator(),mappedDtoUpdtd.getEmployeeTotalIndicator(),"employeeTotalIndicator",tcsId);
				comapreFunction (mappedDtoOld.getIncludePrinciplesIndicator(),mappedDtoUpdtd.getIncludePrinciplesIndicator(),"includePrinciplesIndicator",tcsId);
				comapreFunction (mappedDtoOld.getAgentIndicator(),mappedDtoUpdtd.getAgentIndicator(),"agentIndicator",tcsId);
				comapreFunction (mappedDtoOld.getLegalStatus(),mappedDtoUpdtd.getLegalStatus(),"legalStatus",tcsId);
				comapreFunction (mappedDtoOld.getControlIndicator(),mappedDtoUpdtd.getControlIndicator(),"controlIndicator",tcsId);
				comapreFunction (mappedDtoOld.getStatusCode(),mappedDtoUpdtd.getStatusCode(),"statusCode",tcsId);
				comapreFunction (mappedDtoOld.getSubsidiaryCode(),mappedDtoUpdtd.getSubsidiaryCode(),"subsidiaryCode",tcsId);
				comapreFunction (mappedDtoOld.getFiller2(),mappedDtoUpdtd.getFiller2(),"filler2",tcsId);
				comapreFunction (mappedDtoOld.getPreviousDunsNumber(),mappedDtoUpdtd.getPreviousDunsNumber(),"previousDunsNumber",tcsId);
				comapreFunction (mappedDtoOld.getReportDate(),mappedDtoUpdtd.getReportDate(),"reportDate",tcsId);
				comapreFunction (mappedDtoOld.getFiller3(),mappedDtoUpdtd.getFiller3(),"filler3",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterDunsNumber(),mappedDtoUpdtd.getHeadquarterDunsNumber(),"headquarterDunsNumber",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterBusinessName(),mappedDtoUpdtd.getHeadquarterBusinessName(),"headquarterBusinessName",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterStreetAddress(),mappedDtoUpdtd.getHeadquarterStreetAddress(),"headquarterStreetAddress",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterCity(),mappedDtoUpdtd.getHeadquarterCity(),"headquarterCity",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterState(),mappedDtoUpdtd.getHeadquarterState(),"headquarterState",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterCountryName(),mappedDtoUpdtd.getHeadquarterCountryName(),"headquarterCountryName",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterCityCode(),mappedDtoUpdtd.getHeadquarterCityCode(),"headquarterCityCode",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterCountyCode(),mappedDtoUpdtd.getHeadquarterCountyCode(),"headquarterCountyCode",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterStateAbbreviation(),mappedDtoUpdtd.getHeadquarterStateAbbreviation(),"headquarterStateAbbreviation",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterCountryCode(),mappedDtoUpdtd.getHeadquarterCountryCode(),"headquarterCountryCode",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterPostalCode(),mappedDtoUpdtd.getHeadquarterPostalCode(),"headquarterPostalCode",tcsId);
				comapreFunction (mappedDtoOld.getHeadquarterContinentCode(),mappedDtoUpdtd.getHeadquarterContinentCode(),"headquarterContinentCode",tcsId);
				comapreFunction (mappedDtoOld.getFiller4(),mappedDtoUpdtd.getFiller4(),"filler4",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateDunsNumber(),mappedDtoUpdtd.getDomesticUltimateDunsNumber(),"domesticUltimateDunsNumber",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateBusinessName(),mappedDtoUpdtd.getDomesticUltimateBusinessName(),"domesticUltimateBusinessName",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateStreetAddress(),mappedDtoUpdtd.getDomesticUltimateStreetAddress(),"domesticUltimateStreetAddress",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateCityName(),mappedDtoUpdtd.getDomesticUltimateCityName(),"domesticUltimateCityName",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateStateName(),mappedDtoUpdtd.getDomesticUltimateStateName(),"domesticUltimateStateName",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateCityCode(),mappedDtoUpdtd.getDomesticUltimateCityCode(),"domesticUltimateCityCode",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateCountryCode(),mappedDtoUpdtd.getDomesticUltimateCountryCode(),"domesticUltimateCountryCode",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimateStateAbbreviation(),mappedDtoUpdtd.getDomesticUltimateStateAbbreviation(),"domesticUltimateStateAbbreviation",tcsId);
				comapreFunction (mappedDtoOld.getDomesticUltimatePostalCode(),mappedDtoUpdtd.getDomesticUltimatePostalCode(),"domesticUltimatePostalCode",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateIndicator(),mappedDtoUpdtd.getGlobalUltimateIndicator(),"globalUltimateIndicator",tcsId);
				comapreFunction (mappedDtoOld.getFiller5(),mappedDtoUpdtd.getFiller5(),"filler5",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateDunsNumber(),mappedDtoUpdtd.getGlobalUltimateDunsNumber(),"globalUltimateDunsNumber",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateName(),mappedDtoUpdtd.getGlobalUltimateName(),"globalUltimateName",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateStreetAddress(),mappedDtoUpdtd.getGlobalUltimateStreetAddress(),"globalUltimateStreetAddress",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateCityName(),mappedDtoUpdtd.getGlobalUltimateCityName(),"globalUltimateCityName",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateState(),mappedDtoUpdtd.getGlobalUltimateState(),"globalUltimateState",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateCountryName(),mappedDtoUpdtd.getGlobalUltimateCountryName(),"globalUltimateCountryName",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateCityCode(),mappedDtoUpdtd.getGlobalUltimateCityCode(),"globalUltimateCityCode",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateCountyCode(),mappedDtoUpdtd.getGlobalUltimateCountyCode(),"globalUltimateCountyCode",tcsId);
				comapreFunction (mappedDtoOld.getGlobalultimateStateAbbreviation(),mappedDtoUpdtd.getGlobalultimateStateAbbreviation(),"globalultimateStateAbbreviation",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateCountryCode(),mappedDtoUpdtd.getGlobalUltimateCountryCode(),"globalUltimateCountryCode",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimatePostalCode(),mappedDtoUpdtd.getGlobalUltimatePostalCode(),"globalUltimatePostalCode",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateContinentCode(),mappedDtoUpdtd.getGlobalUltimateContinentCode(),"globalUltimateContinentCode", tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateUS1987PrimarySICCode(),mappedDtoUpdtd.getGlobalUltimateUS1987PrimarySICCode(),"globalUltimateUS1987PrimarySICCode",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateEmployeesTotal(),mappedDtoUpdtd.getGlobalUltimateEmployeesTotal(),"globalUltimateEmployeesTotal",tcsId);
				comapreFunction (mappedDtoOld.getGlobalUltimateAnnualSales(),mappedDtoUpdtd.getGlobalUltimateAnnualSales(),"globalUltimateAnnualSales",tcsId);
				comapreFunction (mappedDtoOld.getNumberOfFamilyMembers(),mappedDtoUpdtd.getNumberOfFamilyMembers(),"numberOfFamilyMembers",tcsId);
				comapreFunction (mappedDtoOld.getDiasCode(),mappedDtoUpdtd.getDiasCode(),"diasCode",tcsId);
				comapreFunction (mappedDtoOld.getHierarchyCode(),mappedDtoUpdtd.getHierarchyCode(),"hierarchyCode",tcsId);
				comapreFunction (mappedDtoOld.getFamilyUpdateDate(),mappedDtoUpdtd.getFamilyUpdateDate(),"familyUpdateDate",tcsId);
				comapreFunction (mappedDtoOld.getOutOfBusinessIndicator(),mappedDtoUpdtd.getOutOfBusinessIndicator(),"outOfBusinessIndicator",tcsId);
				comapreFunction (mappedDtoOld.getMarketableIndicator(),mappedDtoUpdtd.getMarketableIndicator(),"marketableIndicator",tcsId);
				comapreFunction (mappedDtoOld.getLocationOOB(),mappedDtoUpdtd.getLocationOOB(),"locationOOB",tcsId);
				comapreFunction (mappedDtoOld.getEntityOOB(),mappedDtoUpdtd.getEntityOOB(),"entityOOB",tcsId);




			}else{

				System.out.println("The updated json string is same as the last updated json string");

			}

			ObjectMapper mapper = new ObjectMapper();
			String jsonInString;
			System.out.println("Map of company dto " +mapCompDto +"Size of mapcom "+mapCompDto.size());
			jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapCompDto);
			System.out.println(jsonInString);

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 


	}

	public void compareAllFields() throws ComparisonException{

		mapCompDto = new HashMap<Integer, List<ComparisonDto>>();
		listComparisonDto =new ArrayList<ComparisonDto>();
		Map<Integer,String> latestCopmanyDataJson = dao.getLatestCompanyData();
		Map<Integer,String> lastUpdatedCompData =dao.getLastUpdatedCompanyData();

		System.out.println("size of latestCopmanyDataJson " +latestCopmanyDataJson.size());
		System.out.println("size of lastUpdatedCompData "+lastUpdatedCompData.size());
		compareJsonStrings(latestCopmanyDataJson,lastUpdatedCompData);



	}

	private void comapreFunction(String lastUpdatedValue, String newUpdatedValue, String attribute, Integer tcsId) {

		//System.out.println("oldValue : "+lastUpdatedValue);
		//System.out.println("newValue : "+newUpdatedValue);
		boolean old=	emptyCheck(lastUpdatedValue);
		boolean newV=emptyCheck(newUpdatedValue);

		if(!(old && newV)){

			if(old){

				lastUpdatedValue ="null";
			}
			if(newV){
				newUpdatedValue="null";
			}


			// one true and other false  -- ideally should 

			if(!lastUpdatedValue.equalsIgnoreCase(newUpdatedValue)){

				System.out.println("into "+attribute);
				ComparisonDto compDto = new ComparisonDto();
				compDto.setAttribute(attribute);
				compDto.setUpdatedValue(newUpdatedValue);
				compDto.setOldValue(lastUpdatedValue);
				listComparisonDto.add(compDto);
				mapCompDto.put(tcsId, listComparisonDto);

			}else{
				System.out.println("There is no change in "+attribute);

			}
		}else{
			System.out.println("Both Values are null so there is no change in " +lastUpdatedValue +" and " +lastUpdatedValue);
		}
	}

	//	}


	public boolean emptyCheck(String value) {
		boolean flag=false;
		//System.out.println("value for empty check : "+value);
		if(value == null ||  "".equalsIgnoreCase(value.trim()) || value.isEmpty()){
			flag=true;
		}
		return flag;
	}




}

