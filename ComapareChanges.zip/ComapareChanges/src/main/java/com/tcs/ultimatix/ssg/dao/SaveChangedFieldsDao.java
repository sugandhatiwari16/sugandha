package com.tcs.ultimatix.ssg.dao;

import java.util.Map;

import com.tcs.ultimatix.ssg.exception.ComparisonException;

public interface SaveChangedFieldsDao {
	public Map<Integer,String> getLatestCompanyData() throws ComparisonException;
	public Map<Integer,String> getLastUpdatedCompanyData() throws ComparisonException;

}
