package com.tcs.ultimatix.ssg.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.tcs.ultimatix.ssg.exception.ComparisonException;
import com.tcs.ultimatix.ssg.queries.Queries;
import com.ultimatix.ssg.gtsource.service.GTsource;
import com.ultimatix.ssg.gtsource.service.GTsourceImpl;

public class SaveChangedFieldsDaoImpl implements SaveChangedFieldsDao {

	public Map<Integer,String> getLatestCompanyData() throws ComparisonException{
		System.out.println("-----------------------------getLatestCompanyData--------------------------------------");

		Map<Integer,String> mapOfTcsIdData = new HashMap<Integer,String>();

		JdbcTemplate jdbcTemplate = null;
		GTsource gtSource = new GTsourceImpl();

		List<Integer> listOfTcsId=	getListOfTcsID();

		for(Integer tcsId:listOfTcsId){


			try {

				jdbcTemplate = new JdbcTemplate(gtSource.getGTDataSource());

				List<Map<String, Object>> list = jdbcTemplate.queryForList(Queries.GETLatestUpdatedData,new Object[]{tcsId,tcsId});

				if(list!=null && !list.isEmpty()){
					for (Map<String, Object> companyDetail : list) {
						String latestUpdated= (String)companyDetail.get("company_data");
						Timestamp created_on= (Timestamp) companyDetail.get("created_on");
						/*System.out.println("created on value"+created_on);
						System.out.println("Latest updated json is "+latestUpdated);*/
						mapOfTcsIdData.put(tcsId, latestUpdated);

					}
				}
				else{
					System.out.println("There is no data for ");
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("MapOf tcs data "+mapOfTcsIdData);
		return mapOfTcsIdData;
	}



	public Map<Integer,String>  getLastUpdatedCompanyData() throws ComparisonException{
		System.out.println("-----------------------------getLastUpdatedCompanyData--------------------------------------");

		Map<Integer,String> mapOfTcsIdData = new HashMap<Integer,String>();
		JdbcTemplate jdbcTemplate = null;
		GTsource gtSource = new GTsourceImpl();
		List<Integer> listOfTcsId=	getListOfTcsID();
		for(Integer tcsId:listOfTcsId){
			try {
				jdbcTemplate = new JdbcTemplate(gtSource.getGTDataSource());
				
				List<Map<String, Object>> list = jdbcTemplate.queryForList(Queries.GETLastUpdatedData,new Object[]{tcsId,tcsId});
				if(list!=null && !list.isEmpty()){
					for (Map<String, Object> companyDetail : list) {
						String lastUpdated= (String)companyDetail.get("company_data");
						Timestamp created_on= (Timestamp) companyDetail.get("created_on");
						/*System.out.println("created on value"+created_on);
						System.out.println("Last Updated json is "+lastUpdated);*/
						mapOfTcsIdData.put(tcsId, lastUpdated);

					}
				}
				else{
					throw new ComparisonException("No new record present for the given tcs_id");
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return mapOfTcsIdData;
	}

	public List<Integer> getListOfTcsID(){


		JdbcTemplate jdbcTemplate = null;
		GTsource gtSource = new GTsourceImpl();
		List<Integer> listOfTcsId =new ArrayList<Integer>();

		try {
			jdbcTemplate = new JdbcTemplate(gtSource.getGTDataSource());
			String query = Queries.getListOfTcsId;
			listOfTcsId = jdbcTemplate.queryForList(query, Integer.class);
			System.out.println(listOfTcsId.size() +" "+ listOfTcsId);


		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return listOfTcsId;
	}

}