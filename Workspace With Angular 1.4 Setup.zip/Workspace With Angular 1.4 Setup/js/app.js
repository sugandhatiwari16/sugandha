var $ = window.jQuery, app = window.angular.module('mistyloops', ['ngAnimate']);

app.controller('parent-controller', ['$scope', '$timeout',  function (scope, timeout) {
    'use strict';

    scope.listOfBackgroundImages = [
        'url(img/bg_landscape-tree.jpeg)',
        'url(img/bg_landscape-mountain.jpeg)'
    ];

    scope.returnRandomOutput = function (arr) {
        var randomNum = Math.floor(Math.random() * (arr.length));
        return arr[randomNum];
    };

    scope.alternateBackgrounds = function () {
        var background_url = scope.returnRandomOutput(scope.listOfBackgroundImages);
        $('.banner').css({
            'background-image' : background_url
        });
    };
    
    scope.alternateBackgrounds();

    scope.resetForms = function () {
        scope.loginParams = undefined;
        scope.signupParams = undefined;
    };

    scope.hideThenReveal = function (elem1, elem2) {
        scope.closeError();
        elem1.hide();
        elem2.show();
        scope.resetForms();
    };

    scope.showSignupForm = function () {
        scope.hideThenReveal($('#loginForm'), $('#signupForm'));
    };

    scope.showLoginForm = function () {
        scope.hideThenReveal($('#signupForm'), $('#loginForm'));
    };

    scope.showPasswordRecovery = function () {
        scope.hideThenReveal($('#loginForm'), $('#forgotPasswordForm'));
    };

    scope.showLoginFormFromPasswordRecovery = function () {
        scope.hideThenReveal($('#forgotPasswordForm'), $('#loginForm'));
    };

    scope.closeError = function () {
        scope.errorInForm = false;
        scope.successInForm = false;
    };

    scope.showError = function (err) {
        $('.error-box .error-content').text(err);
        scope.errorInForm = true;
        timeout(function () {
            scope.errorInForm = false;
        }, 2000);
    };

    scope.showSuccess = function (msg) {
        $('.success-box .success-content').text(msg);
        scope.successInForm = true;
        timeout(function () {
            scope.successInForm = false;
            scope.resetForms();
            $('#signupForm').hide();
            $('#forgotPasswordForm').hide();
            $('#loginForm').show();
        }, 2000);
    };

    scope.login = function () {
        scope.errorInForm = false;
        if (!scope.loginParams) {
            scope.showError('Kindly Enter Username and Password');
        } else if (!scope.loginParams.username) {
            scope.showError('Kindly Enter Username');
        } else if (!scope.loginParams.password) {
            scope.showError('Kindly Enter Password');
        } else if (Number(scope.loginParams.username)) {
            scope.showError('Username cannot be just numbers!');
        } else {
            /*
            *   Business Logic here
            *   To login the user
            */
            scope.showSuccess("Logged in");
        }
    };

    scope.signup = function () {
        scope.errorInForm = false;
        if (!scope.signupParams) {
            scope.showError('Kindly Enter Username and Password');
        } else if (!scope.signupParams.username) {
            scope.showError('Kindly Enter Username');
        } else if (!scope.signupParams.password) {
            scope.showError('Kindly Enter Password');
        } else if (!scope.signupParams.confirmPassword) {
            scope.showError('Kindly Confirm Your Password');
        } else if (scope.signupParams.confirmPassword !== scope.signupParams.password) {
            scope.showError('Passwords do not match!');
        } else if (Number(scope.signupParams.username)) {
            scope.showError('Username cannot be just numbers!');
        } else {
            /*
            *   Business Logic here
            *   To register the user
            */
            scope.showSuccess('Awesome! Kindly Login Now');
        }
    };

    scope.recoverPassword = function () {
        scope.errorInForm = false;
        if (!scope.recoverPasswordParams) {
            scope.showError('Kindly Enter Email ID');
        } else {
            /*
            *   Business Logic here
            *   To recover the user's password
            */
            scope.showSuccess('Awesome! We will send you a link to recover the password');
        }
    };
}]);